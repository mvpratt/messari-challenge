# Messari Market Data Coding Challenge

Here is the source for the binaries provided with this exercise. Feel free to tinker with it in whatever way you wish during testing, but please keep in mind that an unaltered version will be used on our side to assess performance.

Can be compiled with a standard Go toolchain—standard libraries only! With a working Go toolchain, run via

```
go run main.go
```